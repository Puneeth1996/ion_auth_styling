/* Russian translation for the jQuery Timepicker Addon */
/* Written by Trent Richardson */
(function($) {
	$.timepicker.regional['ru'] = {
		timeOnlyTitle: 'Выберите время',
		timeText: 'Время',
		hourText: 'Часы',
		minuteText: 'Минуты',
		secondText: 'Секунды',
		millisecText: 'Миллисекунды',
		timezoneText: 'Часовой пояс',
		currentText: 'Сейчас',
		closeText: 'Закрыть',
		timeFormat: 'hh:mm tt',
		amNames: ['AM', 'A'],
		pmNames: ['PM', 'P'],
		ampm: false,
		isRTL: false
	};
	$.timepicker.setDefaults($.timepicker.regional['ru']);
})(jQuery);