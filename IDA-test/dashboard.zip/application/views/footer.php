</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- END: Page Main-->

<!-- Theme Customizer -->

<!-- END: Footer-->
<!-- BEGIN VENDOR JS-->

<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->
<!-- END PAGE VENDOR JS-->
<!-- BEGIN THEME  JS-->
<script src="<?php echo base_url() ?>assets/plugins.js" type="text/javascript"></script>
<!--<script src="<?php echo base_url() ?>assets/custom-script.js" type="text/javascript"></script>-->
<!-- END THEME  JS-->
<!-- BEGIN PAGE LEVEL JS-->
<!-- END PAGE LEVEL JS-->
